​
<?php $__env->startSection('title'); ?>
    <title>Edit User CBT</title>
<?php $__env->stopSection(); ?>
​
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Edit User Cbt</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Manajemen CBT</a></li>
                            <li class="breadcrumb-item"><a href="#">User</a></li>
                            <li class="breadcrumb-item active">Edit</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
​
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('header'); ?>
                                Edit
                            <?php $__env->endSlot(); ?>
                            
                            <?php $__env->slot('body'); ?>
                            <?php if(session('error')): ?>
                                @alert(['type' => 'danger'])
                                    <?php echo session('error'); ?>

                                @endalert
                            <?php endif; ?>
​
                            <form role="form" action="<?php echo e(route('User.update', $cbt->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="PUT">
                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <input type="text" name="nama" value="<?php echo e($cbt->nama); ?>" class="form-control <?php echo e($errors->has('nama') ? 'is-invalid':''); ?>" id="nama" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="text" name="email" value="<?php echo e($cbt->email); ?>" class="form-control <?php echo e($errors->has('email') ? 'is-invalid':''); ?>" id="nama" required>
                                </div>
                                <div class="form-group">
                                    <label for="no_hp">No Handphone</label>
                                    <input type="text" name="no_hp" value="<?php echo e($cbt->no_hp); ?>" class="form-control <?php echo e($errors->has('no_hp') ? 'is-invalid':''); ?>" id="no_hp" required>
                                </div>
                                <?php $__env->endSlot(); ?>
                            <?php $__env->slot('footer'); ?>
                                <div class="card-footer">
                                    <button class="btn btn-info"><i class="fa fa-edit"></i> Update</button>
                                </div>
                            </form>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.CBT.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/CBT/User/edit.blade.php ENDPATH**/ ?>