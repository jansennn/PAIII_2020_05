<script src="js_wisatawan/jquery.min.js"></script>
  <script src="js_wisatawan/jquery-migrate-3.0.1.min.js"></script>
  <script src="js_wisatawan/popper.min.js"></script>
  <script src="js_wisatawan/bootstrap.min.js"></script>
  <script src="js_wisatawan/jquery.easing.1.3.js"></script>
  <script src="js_wisatawan/jquery.waypoints.min.js"></script>
  <script src="js_wisatawan/jquery.stellar.min.js"></script>
  <script src="js_wisatawan/owl.carousel.min.js"></script>
  <script src="js_wisatawan/jquery.magnific-popup.min.js"></script>
  <script src="js_wisatawan/aos.js"></script>
  <script src="js_wisatawan/jquery.animateNumber.min.js"></script>
  <script src="js_wisatawan/bootstrap-datepicker.js"></script>
  <script src="js_wisatawan/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js_wisatawan/google-map.js"></script>
  <script src="js_wisatawan/main.js"></script>
  <link rel="stylesheet" type="text/css" href="Wisatawan/css/style2.css"><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/layouts/wisatawan/module/script_bawah.blade.php ENDPATH**/ ?>