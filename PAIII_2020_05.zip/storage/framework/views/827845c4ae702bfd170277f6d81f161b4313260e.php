​
<?php $__env->startSection('title'); ?>
    <title>Edit Budaya</title>
<?php $__env->stopSection(); ?>
​
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Edit Budaya</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Manajemen Informasi</a></li>
                            <li class="breadcrumb-item"><a href="#">Budaya</a></li>
                            <li class="breadcrumb-item active">Edit</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
​
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('header'); ?>
                                Edit
                            <?php $__env->endSlot(); ?>
                            
                            <?php $__env->slot('body'); ?>
                            <?php if(session('error')): ?>
                                @alert(['type' => 'danger'])
                                    <?php echo session('error'); ?>

                                @endalert
                            <?php endif; ?>
​
                            <form role="form" action="<?php echo e(route('Budaya.update', $budaya->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="PUT">
                                <div class="form-group">
                                    <label for="nama_budaya">Nama Budaya</label>
                                    <input type="text" name="nama_budaya" value="<?php echo e($budaya->nama_budaya); ?>" class="form-control <?php echo e($errors->has('nama_budaya') ? 'is-invalid':''); ?>" id="nama_budaya" required>
                                </div>
                                <div class="form-group">
                                    <label for="lokasi">Lokasi</label>
                                    <textarea name="lokasi" id="lokasi" cols="5" rows="5" class="form-control <?php echo e($errors->has('lokasi') ? 'is-invalid':''); ?>" required=""><?php echo e($budaya->lokasi); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="deskripsi">Deskripsi</label>
                                    <textarea class="ckeditor"  name="deskripsi" id="ckedtor" cols="5" rows="5" class="form-control <?php echo e($errors->has('deskripsi') ? 'is-invalid':''); ?>" required=""> <?php echo e($budaya->deskripsi); ?> </textarea>
                                </div>
                                <?php $__env->endSlot(); ?>
                            <?php $__env->slot('footer'); ?>
                                <div class="card-footer">
                                    <button class="btn btn-info"><i class="fa fa-edit"></i> Update</button>
                                </div>
                            </form>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.CBT.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/CBT/Budaya/edit.blade.php ENDPATH**/ ?>