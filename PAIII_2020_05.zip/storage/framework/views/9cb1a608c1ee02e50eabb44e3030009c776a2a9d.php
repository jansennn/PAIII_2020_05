<nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
        </li>
    </ul>
​    <ul class="navbar-nav ml-auto">
        <a href="<?php echo e(url('/autentikasi/logout')); ?>"><button class="btn btn-warning">Logout</button></a>
    </ul>
</nav><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/layouts/CBT/module/nav.blade.php ENDPATH**/ ?>