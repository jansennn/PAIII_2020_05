<div class="alert alert-success" role="alert">
  <?php echo e($message); ?>

</div><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/components/alert.blade.php ENDPATH**/ ?>