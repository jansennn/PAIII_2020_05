<footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="http://adminlte.io">PAIII-2020-05 </a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Sistem Informasi</b> di Kawasan Danau Toba
    </div>
</footer><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/layouts/CBT/module/footer.blade.php ENDPATH**/ ?>