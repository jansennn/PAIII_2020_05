​
<?php $__env->startSection('title'); ?>
    <title>Edit Kategori</title>
<?php $__env->stopSection(); ?>
​
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Edit Objek Wisata</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Manajemen Informasi</a></li>
                            <li class="breadcrumb-item"><a href="#">Objek Wisata</a></li>
                            <li class="breadcrumb-item active">Edit</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
​
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('header'); ?>
                                Edit
                            <?php $__env->endSlot(); ?>
                            
                            <?php $__env->slot('body'); ?>
                            <?php if(session('error')): ?>
                                @alert(['type' => 'danger'])
                                    <?php echo session('error'); ?>

                                @endalert
                            <?php endif; ?>
​
                            <form role="form" action="<?php echo e(route('ObjekWisata.update', $objekWisata->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="PUT">
                                <div class="form-group">
                                    <label for="nama_objek_wisata">Nama Objek Wisata</label>
                                    <input type="text" 
                                        name="nama_objek_wisata"
                                        value="<?php echo e($objekWisata->nama_objek_wisata); ?>"
                                        class="form-control <?php echo e($errors->has('nama_objek_wisata') ? 'is-invalid':''); ?>" id="nama_objek_wisata" required>
                                </div>
                                <div class="form-group">
                                    <label for="kabupaten_id">Kabupaten</label>
                                    <select class="form-control" name="kabupaten_id" readonly>
                                            <option value="<?php echo e($objekWisata->kabupaten_id); ?>"><?php echo e($objekWisata->kabupaten->nama_kabupaten); ?></option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="category_id">Category Wisata</label>
                                    <select class="form-control" name="category_id">
                                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->nama_category); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="lokasi">Lokasi</label>
                                    <textarea name="lokasi" id="lokasi" cols="5" rows="5" class="form-control <?php echo e($errors->has('lokasi') ? 'is-invalid':''); ?>" value="<?php echo e($objekWisata->lokasi); ?>" required=""><?php echo e($objekWisata->lokasi); ?></textarea>
                                </div>
                                <!-- <div class="form-group">
                                    <label for="foto">Foto</label>
                                    <input type="file" name="foto" id="foto" class="form-control <?php echo e($errors->has('foto') ? 'is-invalid':''); ?>" value="" required="">
                                </div> -->
                                <div class="form-group">
                                    <label for="longitude">Longitude</label>
                                    <input type="text" name="longitude" id="longitude" value="<?php echo e($objekWisata->longitude); ?>" class="form-control <?php echo e($errors->has('longitude') ? 'is-invalid':''); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="latitude">Latitude</label>
                                    <input type="text" name="latitude" id="latitude" value="<?php echo e($objekWisata->latitude); ?>" class="form-control <?php echo e($errors->has('latitude') ? 'is-invalid':''); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="deskripsi">Deskripsi</label>
                                    <textarea class="ckeditor"  name="deskripsi" id="ckedtor" cols="5" rows="5" value="<?php echo e($objekWisata->deskripsi); ?>" class="form-control <?php echo e($errors->has('deskripsi') ? 'is-invalid':''); ?>" required=""><?php echo e($objekWisata->deskripsi); ?></textarea>
                                </div>
                                <?php $__env->endSlot(); ?>
                            <?php $__env->slot('footer'); ?>
                                <div class="card-footer">
                                    <button class="btn btn-info"><i class="fa fa-edit"></i> Update</button>
                                </div>
                            </form>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.CBT.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/CBT/ObjekWisata/edit.blade.php ENDPATH**/ ?>