​
<?php $__env->startSection('title'); ?>
    <title>Edit Transportasi</title>
<?php $__env->stopSection(); ?>
​
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Edit Transportasi</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Manajemen Informasi</a></li>
                            <li class="breadcrumb-item"><a href="#">Transportasi</a></li>
                            <li class="breadcrumb-item active">Edit</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
​
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('header'); ?>
                                Edit
                            <?php $__env->endSlot(); ?>
                            
                            <?php $__env->slot('body'); ?>
                            <?php if(session('error')): ?>
                                @alert(['type' => 'danger'])
                                    <?php echo session('error'); ?>

                                @endalert
                            <?php endif; ?>
​
                            <form role="form" action="<?php echo e(route('Transportasi.update', $transportasi->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="PUT">
                                <div class="form-group">
                                    <label for="nama_transportasi">Nama Transportasi</label>
                                    <input type="text" name="nama_transportasi" value="<?php echo e($transportasi->nama_transportasi); ?>" class="form-control <?php echo e($errors->has('nama_transportasi') ? 'is-invalid':''); ?>" id="nama_transportasi" required>
                                </div>
                                <div class="form-group">
                                    <label for="jenis_transportasi">Jenis Transportasi</label>
                                    <input type="text" name="jenis_transportasi" value="<?php echo e($transportasi->jenis_transportasi); ?>" class="form-control <?php echo e($errors->has('jenis_transportasi') ? 'is-invalid':''); ?>" id="jenis_transportasi" required>
                                </div>
                                <div class="form-group">
                                    <label for="tgl_akhir">Alamat</label>
                                    <input type="text" name="alamat" value="<?php echo e($transportasi->alamat); ?>" class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid':''); ?>" id="alamat" required>
                                </div>
                                <div class="form-group">
                                    <label for="deskripsi">Deskripsi</label>
                                    <textarea class="ckeditor"  name="deskripsi" id="ckedtor" cols="5" rows="5" class="form-control <?php echo e($errors->has('deskripsi') ? 'is-invalid':''); ?>" required=""> <?php echo e($transportasi->deskripsi); ?> </textarea>
                                </div>
                                <?php $__env->endSlot(); ?>
                            <?php $__env->slot('footer'); ?>
                                <div class="card-footer">
                                    <button class="btn btn-info"><i class="fa fa-edit"></i> Update</button>
                                </div>
                            </form>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.CBT.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/CBT/Transportasi/edit.blade.php ENDPATH**/ ?>