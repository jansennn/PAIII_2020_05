​
<?php $__env->startSection('title'); ?>
    <title>Manajemen User CBT</title>
<?php $__env->stopSection(); ?>
​
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Manajemen User CBT</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Manajemen CBT</a></li>
                            <li class="breadcrumb-item active">Register User</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
​
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4">
                        <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('header'); ?>
                                <b>Tambah</b>
                            <?php $__env->endSlot(); ?>
                            
                            <?php if(session('error')): ?>
                                @alert(['type' => 'danger'])
                                    <?php echo session('error'); ?>

                                @endalert
                            <?php endif; ?>
​                            <?php $__env->slot('body'); ?>   
                            <form role="form" action="<?php echo e(route('User.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="name">Nama User</label>
                                    <input type="text" 
                                    name="nama"
                                    class="form-control <?php echo e($errors->has('nama') ? 'is-invalid':''); ?>" id="nama" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="text" name="email"
                                    class="form-control <?php echo e($errors->has('email') ? 'is-invalid':''); ?>" id="email" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="text" 
                                    name="password"
                                    class="form-control <?php echo e($errors->has('password') ? 'is-invalid':''); ?>" id="password" required>
                                </div>
                                <div class="form-group">
                                    <label for="no_hp">No Handphone</label>
                                    <input type="text" 
                                    name="no_hp"
                                    class="form-control <?php echo e($errors->has('no_hp') ? 'is-invalid':''); ?>" id="no_hp" required>
                                </div>
                            <?php $__env->endSlot(); ?>    
                            <?php $__env->slot('footer'); ?>
                                <div class="card-footer">
                                    <button class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="col-md-8">
                    <?php $__env->startComponent('components.card'); ?>
                                <?php $__env->slot('header'); ?>
                                <b>List User CBT</b>
                            <?php $__env->endSlot(); ?>
                            
                            <?php $__env->slot('body'); ?>
                            <?php if(session('success')): ?>
                                <?php $__env->startComponent('components.alert'); ?>
                                    <?php $__env->slot('message'); ?>
                                        <?php echo session('success'); ?>

                                    <?php $__env->endSlot(); ?>
                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            
                            <div class="table-responsive">
                                <table class="table table-hover">
                                      <thead>
                                        <tr>
                                            <td>#</td>
                                            <td>Nama</td>
                                            <td>Kabupaten</td>
                                            <td>No. Handphone</td>
                                            <td>Terdaftar mulai tanggal</td>
                                            <td>Aksi</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $cbts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($row->nama); ?></td>
                                            <td><?php echo e($row->kabupaten->nama_kabupaten); ?></td>
                                            <td><?php echo e($row->no_hp); ?></td>
                                            <td><?php echo e($row->created_at); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('User.destroy', $row->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <a href="<?php echo e(route('User.edit', $row->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                                    <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">Tidak ada data</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <?php echo e($cbts->links()); ?>

                            </div>
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('footer'); ?>
​                               <i>List User CBT</i>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </section>

    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.CBT.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/CBT/User/index.blade.php ENDPATH**/ ?>