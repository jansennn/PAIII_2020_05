​
<?php $__env->startSection('title'); ?>
    <title>Manajemen Transportasi</title>
<?php $__env->stopSection(); ?>
​
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Manajemen Transportasi</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Manajemen Transportasi</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
​
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4">
                        <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('header'); ?>
                                <b>Tambah</b>
                            <?php $__env->endSlot(); ?>
                            
                            <?php if(session('error')): ?>
                                @alert(['type' => 'danger'])
                                    <?php echo session('error'); ?>

                                @endalert
                            <?php endif; ?>
​                            <?php $__env->slot('body'); ?>   
                            <form role="form" action="<?php echo e(route('Transportasi.store')); ?>" method="POST"  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="nama_transportasi">Nama Transportasi</label>
                                    <input type="text" name="nama_transportasi" class="form-control <?php echo e($errors->has('nama_transportasi') ? 'is-invalid':''); ?>" id="nama_transportasi" required>
                                </div>
                                <div class="form-group">
                                    <label for="kabupaten_id">Kabupaten</label>
                                    <select class="form-control" name="kabupaten_id" readonly>
                                            <option value="<?php echo e($kabupaten->id); ?>"><?php echo e($kabupaten->nama_kabupaten); ?></option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="jenis_transportasi">Jenis Transportasi</label>
                                    <select class="form-control" name="jenis_transportasi">
                                            <option value="Mobil">Mobil</option>
                                            <option value="Sepeda Motor">Sepeda Motor</option>
                                            <option value="Kapal">Kapal</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="alamat">Alamat</label>
                                    <textarea name="alamat" id="alamat" cols="5" rows="5" class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid':''); ?>" required=""></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="foto">Foto</label>
                                    <input type="file" name="foto" id="foto" class="form-control <?php echo e($errors->has('foto') ? 'is-invalid':''); ?>" required="">
                                </div>
                                <div class="form-group">
                                    <label for="deskripsi">Deskripsi</label>
                                    <textarea class="ckeditor"  name="deskripsi" id="ckedtor" cols="5" rows="5" class="form-control <?php echo e($errors->has('deskripsi') ? 'is-invalid':''); ?>" required=""></textarea>
                                </div>
                            <?php $__env->endSlot(); ?>    
                            <?php $__env->slot('footer'); ?>
                                <div class="card-footer">
                                    <button class="btn btn-primary">Simpan</button>
                                </div>
                            </form>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                    <div class="col-md-8">
                    <?php $__env->startComponent('components.card'); ?>
                                <?php $__env->slot('header'); ?>
                                <b>List Transportasi</b>
                            <?php $__env->endSlot(); ?>
                            
                            <?php $__env->slot('body'); ?>
                            <?php if(session('success')): ?>
                                <?php $__env->startComponent('components.alert'); ?>
                                    <?php $__env->slot('message'); ?>
                                        <?php echo session('success'); ?>

                                    <?php $__env->endSlot(); ?>
                                <?php echo $__env->renderComponent(); ?>
                            <?php endif; ?>
                            
                            <div class="table-responsive">
                                <table class="table table-hover">
                                      <thead>
                                        <tr>
                                            <td>#</td>
                                            <td>Nama Transportasi</td>
                                            <td>Kabupaten</td>
                                            <td>Alamat</td>
                                            <td>Jenis Transportasi</td>
                                            <td>Aksi</td>
                                        </tr>
                                    </thead>
                                   <tbody>
                                        <?php $no=1; ?>
                                        <?php $__currentLoopData = $transportasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transportasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($transportasi->nama_transportasi); ?></td>
                                                <td><?php echo e($transportasi->kabupaten->nama_kabupaten); ?></td>
                                                <td><?php echo e($transportasi->alamat); ?></td>
                                                <td><?php echo e($transportasi->jenis_transportasi); ?></td>
                                                
                                                <td><form action="<?php echo e(route('Transportasi.destroy', $transportasi->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <a href="<?php echo e(route('Transportasi.edit', $transportasi->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                                    <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                                </form></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php echo e($transportasis->links()); ?>

                            </div>
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('footer'); ?>
​                               <i>List Transportasi</i>
                            <?php $__env->endSlot(); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </section>

    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.CBT.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/CBT/Transportasi/index.blade.php ENDPATH**/ ?>