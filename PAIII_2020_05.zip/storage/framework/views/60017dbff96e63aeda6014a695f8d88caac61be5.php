<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="Wisatawan/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="Wisatawan/css/animate.css">
    
    <link rel="stylesheet" href="Wisatawan/css/owl.carousel.min.css">
    <link rel="stylesheet" href="Wisatawan/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="Wisatawan/css/magnific-popup.css">

    <link rel="stylesheet" href="Wisatawan/css/aos.css">

    <link rel="stylesheet" href="Wisatawan/css/ionicons.min.css">

    <link rel="stylesheet" href="Wisatawan/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="Wisatawan/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="Wisatawan/css/flaticon.css">
    <link rel="stylesheet" href="Wisatawan/css/icomoon.css">
    <link rel="stylesheet" href="Wisatawan/css/style.css">
    <link rel="stylesheet" href="Wisatawan/css/style2.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/layouts/wisatawan/module/script_atas.blade.php ENDPATH**/ ?>