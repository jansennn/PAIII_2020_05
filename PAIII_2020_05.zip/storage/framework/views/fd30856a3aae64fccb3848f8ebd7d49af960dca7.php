<div class="card">
    <div class="card-header">
        <?php echo e($header); ?>

    </div>
    <div class="card-body">
        <?php echo e($body); ?>

    </div>
    <div>
        <?php echo e($footer); ?>

    </div>
</div><?php /**PATH C:\xampp\htdocs\PA3\PAIII_2020_05\resources\views/components/card.blade.php ENDPATH**/ ?>