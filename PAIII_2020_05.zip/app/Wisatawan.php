<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wisatawan extends Model
{
    //
}
