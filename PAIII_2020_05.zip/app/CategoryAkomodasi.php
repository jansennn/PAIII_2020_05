<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryAkomodasi extends Model
{
    //
}
