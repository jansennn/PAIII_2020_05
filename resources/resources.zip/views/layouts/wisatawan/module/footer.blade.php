 <div id="sec3">
      <div class="container">
        
      </div>
    </div>
<footer class="ftco-footer bg-bottom" style="background-image: url(images/footer-bg.jpg);">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Sistem Informasi Pariwisata Kawasan Danau Toba</h2>
              <p>Danau Toba ,negeri indah kepingan surga.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Kabupaten</h2>
              <ul class="list-unstyled">
                <li><a href="{{url('Kab',['id' => 2])}}" class="py-2 d-block">Toba</a></li>
                <li><a href="{{url('Kab',['id' => 3])}}" class="py-2 d-block">Tapanuli Utara</a></li>
                <li><a href="{{url('Kab',['id' => 5])}}" class="py-2 d-block">Samosir</a></li>
                <li><a href="{{url('Kab',['id' => 1])}}" class="py-2 d-block">Humbang Hasundutan</a></li>
                <li><a href="{{url('Kab',['id' => 4])}}" class="py-2 d-block">Simalungun</a></li>
                <li><a href="{{url('Kab',['id' => 6])}}" class="py-2 d-block">Karo</a></li>
                <li><a href="{{url('Kab',['id' => 7])}}" class="py-2 d-block">Dairi</a></li>
                <li><a href="{{url('Kab',['id' => 8])}}" class="py-2 d-block">Pakpak Barat</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Experience</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Adventure</a></li>
                <li><a href="#" class="py-2 d-block">Hotel and Restaurant</a></li>
                <li><a href="#" class="py-2 d-block">Beach</a></li>
                <li><a href="#" class="py-2 d-block">Nature</a></li>
                <li><a href="#" class="py-2 d-block">Camping</a></li>
                <li><a href="#" class="py-2 d-block">Party</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Have a Questions?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Kawasan Danau Toba</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+2 392 3929 210</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">danauToba@gmail.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | PAIII - 2020 - 05 
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>