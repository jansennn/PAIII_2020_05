<div class="card">
    <div class="card-header">
        {{ $header }}
    </div>
    <div class="card-body">
        {{ $body }}
    </div>
    <div>
        {{ $footer }}
    </div>
</div>